package com.led.led;

import android.content.Intent;
import android.os.Bundle;
import com.takisoft.datetimepicker.DatePickerDialog;
import android.view.View;
import android.view.WindowManager;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.google.android.material.snackbar.Snackbar;
import java.util.Calendar;
import java.util.Date;
import info.hoang8f.widget.FButton;
import static com.led.led.DeviceList.EXTRA_ADDRESS;

public class SelectionScreen extends AppCompatActivity {

    TextView txtDob;
    CardView cardFemale, cardMale;
    FButton btnProceed;
    Spinner spGender;
    int check = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selection_screen);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setupLayout();

        Calendar cal = Calendar.getInstance();
        spGender = findViewById(R.id.spGender);
        cardFemale = findViewById(R.id.cardFemale);
        cardMale = findViewById(R.id.cardMale);

        cardFemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check = 1;
                cardFemale.setCardBackgroundColor(getResources().getColor(R.color.btnbackground));
                cardMale.setCardBackgroundColor(getResources().getColor(R.color.white));
            }
        });

        cardMale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check = 2;
                cardMale.setCardBackgroundColor(getResources().getColor(R.color.btnbackground));
                cardFemale.setCardBackgroundColor(getResources().getColor(R.color.white));
            }
        });

        btnProceed = findViewById(R.id.btnProceed);
        btnProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (check == 0) {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Select gender", Snackbar.LENGTH_LONG);
                    snackbar.show();
                } else if (spGender.getSelectedItem().toString().equals("Age Group")) {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Select age group", Snackbar.LENGTH_LONG);
                    snackbar.show();
                } else {
                    Intent i = new Intent(SelectionScreen.this, ledControl.class);
                    //Change the activity.
                    i.putExtra(EXTRA_ADDRESS, getIntent().getStringExtra(EXTRA_ADDRESS)); //this will be received at ledControl (class) Activity
                    startActivity(i);
                }
            }
        });

        txtDob = findViewById(R.id.txtDob);
        txtDob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog dpd = new DatePickerDialog(SelectionScreen.this, (view1, year, month, dayOfMonth) -> {
                    txtDob.setText(getAge(year, month, dayOfMonth) + " years old");

                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE));
                dpd.show();
            }
        });

    }

    public int getAge(int year, int month, int day) {
        Date now = new Date();
        int nowMonth = now.getMonth() + 1;
        int nowYear = now.getYear() + 1900;
        int result = nowYear - year;

        if (month > nowMonth) {
            result--;
        } else if (month == nowMonth) {
            int nowDay = now.getDate();

            if (day > nowDay) {
                result--;
            }
        }
        return result;
    }

    private void setupLayout() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
    }

}
