# HC-05
Android App for Home Automation using Bluetooth Module & Arduino

1. Upload Bluetooth.ino to Arduino.
2. Connect HC-05 to Arduino.
3. Import & Run the project in Android Studio.
